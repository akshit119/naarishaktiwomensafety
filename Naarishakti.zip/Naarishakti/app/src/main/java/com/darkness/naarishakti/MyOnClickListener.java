package com.darkness.naarishakti;

public interface MyOnClickListener {
    void onItemClicked(int position);
}
